CREATE TABLE `mediumints` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `medium` mediumint,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

