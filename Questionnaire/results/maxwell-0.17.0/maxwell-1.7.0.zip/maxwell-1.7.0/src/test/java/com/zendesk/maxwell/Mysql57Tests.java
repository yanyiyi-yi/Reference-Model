package com.zendesk.maxwell;

public class Mysql57Tests { }


