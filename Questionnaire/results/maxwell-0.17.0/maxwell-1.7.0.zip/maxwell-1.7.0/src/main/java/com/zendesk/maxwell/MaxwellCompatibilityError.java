package com.zendesk.maxwell;

public class MaxwellCompatibilityError extends Exception {
	public MaxwellCompatibilityError(String message) {
		super(message);
	}
	private static final long serialVersionUID = 1L;
}
